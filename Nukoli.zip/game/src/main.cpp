﻿#include "Nukoli.h"
#include <cmath>
#include <cstdlib>

SoundSource music;
std::string playing;

void changeSong() {
    music.reset();
    std::string fileName;
    std::cout << "FILENAME: ";
    fileName = "use";
    playing = fileName;
    music.loadFromFile(fileName + ".ns");
}

// ────────────────────────────────────────────────────────────────────────────
// Globals
// ────────────────────────────────────────────────────────────────────────────
static int  tick = 0;
static int  currentViz = 0;
static bool spaceWasDown = false;

// Drum hit tracking (detects midiNote changes; re-triggers if cooldown < 10
// so rapid same-note repeats still register visually)
static int  lastMidiNote = -1;
static int  hitCooldown = 0;   // counts down from 30; drives visual intensity
static int  hitNote = 0;   // note that caused the current active hit

static const int   NUM_VIZ = 9;
static const float PI = 3.14159265f;

static const char* VIZ_NAMES[NUM_VIZ] = {
    "AURORA CURTAINS",
    "RADIAL PULSE",
    "LISSAJOUS KNOT",
    "STAR TUNNEL",
    "CRYSTAL GRID",
    "DRUM REACTOR",
    "WARP WEB",
    "PLASMA RIBBONS",
    "*** ACID TRIP ***"
};

// ────────────────────────────────────────────────────────────────────────────
// Helpers
// ────────────────────────────────────────────────────────────────────────────
inline int  wc(int c) { return ((c % 16) + 16) % 16; }
inline bool inB(int x, int y) { return x >= 0 && x < 256 && y >= 0 && y < 256; }
inline void SP(int x, int y, int c) { if (inB(x, y)) DrawPixel(x, y, c); }

// Palette colour per drum family
inline int drumColor(int note) {
    if (note == 35 || note == 36)                                            return 3;   // bass:          dark red
    if (note >= 37 && note <= 40)                                            return 13;  // snare/clap:    gold
    if (note == 42 || note == 44)                                            return 7;   // closed hi-hat: teal
    if (note == 46)                                                          return 8;   // open hi-hat:   sage
    if (note == 49 || note == 52 || note == 55 || note == 57)                              return 0;   // crash:         bright tan
    if (note == 51 || note == 53 || note == 59)                                        return 11;  // ride:          warm grey
    if (note == 41 || note == 43 || note == 45 || note == 47 || note == 48 || note == 50)          return 9;   // toms:          muted brown
    if (note == 56 || note == 75 || note == 76 || note == 77)                              return 15;  // cowbell/block: golden
    if (note == 54 || note == 69 || note == 70)                                        return 12;  // shakers:       olive
    return 10;
}

// Decay rate matching the audio engine (used to shape visual character)
inline float drumDecay(int note) {
    switch (note) {
    case 35: case 36:                                       return 12.0f;
    case 37: case 38: case 39: case 40:                     return  8.0f;
    case 41: case 43: case 45: case 47: case 48: case 50:   return  6.0f;
    case 42: case 44:                                       return 20.0f;
    case 46:                                                return  4.0f;
    case 49: case 52: case 55: case 57:                     return  1.5f;
    case 51: case 53: case 59:                              return  2.5f;
    case 56: case 75: case 76: case 77:                     return 15.0f;
    case 54: case 69: case 70:                              return 10.0f;
    case 60: case 61: case 62: case 63:
    case 64: case 65: case 66:                              return  7.0f;
    case 80: case 81:                                       return  3.0f;
    default:                                                return  8.0f;
    }
}

// 0..1 intensity that fades linearly to zero over 30 frames after a hit
inline float hitFade() { return hitCooldown > 0 ? hitCooldown / 30.0f : 0.0f; }

// ════════════════════════════════════════════════════════════════════════════
// VIZ 0 – AURORA CURTAINS
//   Rippling vertical sine curtains.  Sq1 = bright shimmer edge,
//   Triangle = secondary ripple, Sawtooth = horizontal scan line.
//   Noise specks sized and coloured by active drum family.
// ════════════════════════════════════════════════════════════════════════════
void VizAurora() {
    for (int x = 0; x < 256; x++) {
        float wave = sinf(x * 0.04f + tick * 0.04f) * 38.0f
            + sinf(x * 0.09f - tick * 0.026f) * 17.0f;
        int baseY = 112 + (int)wave;
        int stripeH = 55 + (int)(sinf(x * 0.05f + tick * 0.02f) * 12.0f);
        for (int dy = 0; dy < stripeH; dy++) {
            int y = baseY + dy;
            if (y < 0 || y >= 256) continue;
            SP(x, y, wc((int)(x * 0.065f + tick * 0.045f) + dy / 6));
        }
        if (squareChannel1.amplitude) {
            float f = squareChannel1.frequency;
            int ys = baseY - 14 + (int)(sinf(x * 0.11f + tick * f * 0.0012f) * 11.0f);
            SP(x, ys, 13);  SP(x, ys + 1, 15);
        }
        if (triangleChannel.amplitude) {
            float f = triangleChannel.frequency;
            int yt = baseY - 30 + (int)(cosf(x * 0.08f + tick * f * 0.001f) * 10.0f);
            SP(x, yt, 7);  SP(x, yt + 1, 6);
        }
    }
    if (noiseChannel.amplitude) {
        int col = drumColor(hitNote);
        int sz = 1 + (int)(hitFade() * 3.0f);
        for (int x = 0; x < 256; x += 3) {
            if (((x * 7 + tick * 3) % 5) != 0) continue;
            float wave = sinf(x * 0.04f + tick * 0.04f) * 38.0f + sinf(x * 0.09f - tick * 0.026f) * 17.0f;
            int baseY = 112 + (int)wave;
            for (int s = 0; s < sz; s++)
                SP(x, baseY - 35 + s + (rand() % 18), col);
        }
    }
    if (sawToothChannel.amplitude) {
        float sf = sawToothChannel.frequency;
        int   sy = (int)(tick * sf * 0.003f) & 0xFF;
        for (int x = 0; x < 256; x++)
            SP(x, sy, wc(3 + (int)(x * 0.06f)));
    }
}

// ════════════════════════════════════════════════════════════════════════════
// VIZ 1 – RADIAL PULSE
//   Concentric expanding rings + per-channel rotating tapered spikes.
//   Noise: drum-family ring burst (crash = tight full ring, others = sparse).
// ════════════════════════════════════════════════════════════════════════════
void VizRadialPulse() {
    const int cx = 128, cy = 128;
    static const int ringCols[6] = { 6,7,8,12,13,15 };
    for (int ring = 0; ring < 6; ring++) {
        float r = fmodf((tick * 0.04f - ring * 0.9f) * 12.0f, 118.0f);
        if (r < 0) r += 118.0f;
        for (int a = 0; a < 360; a += 2) {
            float rad = a * PI / 180.0f;
            SP(cx + (int)(cosf(rad) * r), cy + (int)(sinf(rad) * r), ringCols[ring]);
        }
    }
    struct Spike { float freq, amp; int col, n; float rotMul; };
    Spike spikes[4] = {
        {squareChannel1.frequency,  (float)(bool)squareChannel1.amplitude,  13, 8,  1.00f},
        {squareChannel2.frequency,  (float)(bool)squareChannel2.amplitude,   7, 6, -0.70f},
        {triangleChannel.frequency, (float)(bool)triangleChannel.amplitude,  9, 5,  1.30f},
        {sawToothChannel.frequency, (float)(bool)sawToothChannel.amplitude,  3, 4,  0.50f},
    };
    for (auto& s : spikes) {
        if (!s.amp) continue;
        float len = (18.0f + s.freq / 1000.0f * 58.0f) * (1.0f + sinf(tick * 0.13f) * 0.25f);
        float rot = tick * 0.008f * s.rotMul;
        for (int k = 0; k < s.n; k++) {
            float rad = ((float)k / s.n) * 2.0f * PI + rot, perp = rad + PI * 0.5f;
            for (int r = 12; r < (int)len; r++) {
                SP(cx + (int)(cosf(rad) * r), cy + (int)(sinf(rad) * r), s.col);
                if (r < 12 + (int)(len * 0.38f)) {
                    SP(cx + (int)(cosf(rad) * r + cosf(perp) * 1.5f), cy + (int)(sinf(rad) * r + sinf(perp) * 1.5f), wc(s.col + 2));
                    SP(cx + (int)(cosf(rad) * r - cosf(perp) * 1.5f), cy + (int)(sinf(rad) * r - sinf(perp) * 1.5f), wc(s.col + 2));
                }
            }
        }
    }
    if (noiseChannel.amplitude && hitFade() > 0.04f) {
        float hit = hitFade(); int col = drumColor(hitNote);
        float r = (1.0f - hit) * 110.0f;
        int step = (hitNote == 49 || hitNote == 52 || hitNote == 55 || hitNote == 57) ? 2 : 6;
        for (int a = 0; a < 360; a += step) {
            float rad = a * PI / 180.0f;
            SP(cx + (int)(cosf(rad) * r), cy + (int)(sinf(rad) * r), col);
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
// VIZ 2 – LISSAJOUS KNOT
//   Channel audio frequencies set x:y ratios.  Noise renders a rhodonea
//   (rose) curve whose petal count is derived from drumDecay(): fast-decay
//   drums (hi-hat, cowbell) yield many fine petals; slow-decay (cymbal)
//   yield wide arms.
// ════════════════════════════════════════════════════════════════════════════
void VizLissajous() {
    const int cx = 128, cy = 128;
    const float drift = tick * 0.0015f;
    auto liss = [&](float fx, float fy, float phase, float r, int c1, int c2) {
        for (int i = 0; i < 520; i++) {
            float u = (float)i / 520.0f * 2.0f * PI;
            int x = cx + (int)(r * sinf(fx * u + phase)), y = cy + (int)(r * sinf(fy * u));
            SP(x, y, c1); SP(x + 1, y, c2); SP(x, y + 1, c2);
        }
        };
    liss(3.0f, 2.0f, drift, 98.0f, 5, 6);
    if (squareChannel1.amplitude)  liss(fmodf(squareChannel1.frequency / 200.0f, 5.0f) + 1.0f, 2.0f, drift * 1.10f, 88.0f, 13, 15);
    if (squareChannel2.amplitude)  liss(3.0f, fmodf(squareChannel2.frequency / 250.0f, 4.0f) + 1.5f, drift * 0.90f, 72.0f, 7, 8);
    if (triangleChannel.amplitude) liss(fmodf(triangleChannel.frequency / 300.0f, 3.0f) + 2.0f, 3.0f, drift * 1.40f, 78.0f, 9, 12);
    if (sawToothChannel.amplitude) liss(4.0f, fmodf(sawToothChannel.frequency / 400.0f, 3.0f) + 1.5f, -drift * 1.20f, 62.0f, 3, 2);
    if (noiseChannel.amplitude) {
        float decay = drumDecay(hitNote);
        float k = (decay / 4.0f) + 1.0f + sinf(tick * 0.016f) * 0.55f;
        int   col = drumColor(hitNote);
        float rad = 80.0f * (0.8f + hitFade() * 0.2f);
        for (int i = 0; i < 420; i++) {
            float u = (float)i / 420.0f * 2.0f * PI, rv = rad * cosf(k * u);
            SP(cx + (int)(rv * cosf(u)), cy + (int)(rv * sinf(u)), col);
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
// VIZ 3 – STAR TUNNEL
//   Stars stream toward viewer.  Bass drum = warp speed kick,
//   snare = medium kick, cymbal hit = coloured shockwave ring bloom.
// ════════════════════════════════════════════════════════════════════════════
void VizStarTunnel() {
    static float sx[180], sy[180], sz[180];
    static bool init = false;
    if (!init) {
        for (int i = 0; i < 180; i++) {
            sx[i] = (float)((rand() % 512) - 256); sy[i] = (float)((rand() % 512) - 256); sz[i] = (float)(rand() % 256 + 1);
        }
        init = true;
    }
    float speed = 1.9f;
    if (squareChannel1.amplitude)  speed += squareChannel1.frequency / 620.0f;
    if (triangleChannel.amplitude) speed += triangleChannel.frequency / 920.0f;
    if (hitNote == 35 || hitNote == 36)  speed += hitFade() * 8.0f;
    if (hitNote >= 37 && hitNote <= 40)  speed += hitFade() * 4.0f;

    for (int i = 0; i < 180; i++) {
        sz[i] -= speed;
        if (sz[i] <= 0.5f) { sx[i] = (float)((rand() % 480) - 240); sy[i] = (float)((rand() % 480) - 240); sz[i] = 255.0f; }
        float scale = 128.0f / sz[i];
        int px = 128 + (int)(sx[i] * scale), py = 128 + (int)(sy[i] * scale);
        if (!inB(px, py)) continue;
        float depth = sz[i] / 255.0f;
        int c = depth > 0.75f ? 5 : depth > 0.50f ? 6 : depth > 0.30f ? 10 : depth > 0.14f ? 11 : 0;
        SP(px, py, c);
        if (depth < 0.22f) { float ps = 128.0f / (sz[i] + speed * 2.5f); SP(128 + (int)(sx[i] * ps), 128 + (int)(sy[i] * ps), wc(c + 2)); }
    }
    for (int ring = 0; ring < 5; ring++) {
        float r = fmodf(tick * speed * 0.38f + ring * 52.0f, 126.0f);
        int   c = wc(6 + ring + (int)(tick * 0.016f));
        for (int a = 0; a < 360; a += 5) { float rad = a * PI / 180.0f; SP(128 + (int)(cosf(rad) * r), 128 + (int)(sinf(rad) * r), c); }
    }
    if ((hitNote == 49 || hitNote == 52 || hitNote == 55 || hitNote == 57) && hitFade() > 0.08f) {
        float r = hitFade() * 122.0f; int c = drumColor(hitNote);
        for (int a = 0; a < 360; a += 3) { float rad = a * PI / 180.0f; SP(128 + (int)(cosf(rad) * r), 128 + (int)(sinf(rad) * r), c); }
    }
}

// ════════════════════════════════════════════════════════════════════════════
// VIZ 4 – CRYSTAL GRID
//   Three-source ripple interference plasma.
//   Noise specks: count and colour scale with hit intensity and drum family.
// ════════════════════════════════════════════════════════════════════════════
void VizCrystalGrid() {
    float fm = 1.0f;
    if (triangleChannel.amplitude) fm += triangleChannel.frequency / 580.0f;
    if (squareChannel1.amplitude)  fm += squareChannel1.frequency / 1100.0f;
    if (squareChannel2.amplitude)  fm += squareChannel2.frequency / 1100.0f;
    for (int y = 0; y < 256; y += 2) for (int x = 0; x < 256; x += 2) {
        float fx = (x - 128) / 128.0f, fy = (y - 128) / 128.0f;
        float d1 = sqrtf(fx * fx + fy * fy);
        float d2 = sqrtf((fx - 0.48f) * (fx - 0.48f) + (fy - 0.22f) * (fy - 0.22f));
        float d3 = sqrtf((fx + 0.38f) * (fx + 0.38f) + (fy + 0.32f) * (fy + 0.32f));
        float v = sinf(d1 * 12.0f * fm - tick * 0.08f) + sinf(d2 * 14.5f * fm + tick * 0.065f)
            + sinf(d3 * 11.0f * fm - tick * 0.07f) + sinf(fx * fy * 11.0f * fm + tick * 0.042f);
        int c = wc((int)((v + 4.0f) * 2.0f));
        SP(x, y, c); SP(x + 1, y, c); SP(x, y + 1, c); SP(x + 1, y + 1, c);
    }
    if (sawToothChannel.amplitude) {
        float sf = sawToothChannel.frequency / 440.0f;
        for (int i = 0; i < 256; i++) { int sx = (i + (int)(tick * sf * 1.6f)) & 0xFF; SP(sx, i, 13); SP((sx + 1) & 0xFF, i, 15); }
    }
    if (noiseChannel.amplitude) {
        int col = drumColor(hitNote), cnt = 6 + (int)(hitFade() * 26.0f);
        for (int i = 0; i < cnt; i++) SP((rand() + tick * 3) % 256, (rand() + tick * 7) % 256, col);
    }
}

// ════════════════════════════════════════════════════════════════════════════
// VIZ 5 – DRUM REACTOR
//   Each drum family triggers a unique zone effect.  Other channels draw
//   horizontal waveforms.  Background: slow radial breathing.
// ════════════════════════════════════════════════════════════════════════════
void VizDrumReactor() {
    for (int y = 0; y < 256; y += 3) for (int x = 0; x < 256; x += 3) {
        float d = sqrtf((x - 128.0f) * (x - 128.0f) + (y - 128.0f) * (y - 128.0f));
        if (sinf(d * 0.08f - tick * 0.025f) > 0.6f)
            SP(x, y, wc(5 + (int)(d * 0.04f + tick * 0.01f)));
    }
    if (squareChannel1.amplitude) { float f = squareChannel1.frequency; for (int x = 0; x < 256; x++) SP(x, 70 + (int)(sinf(x * 0.05f + tick * f * 0.0008f) * 18.0f), 13); }
    if (squareChannel2.amplitude) { float f = squareChannel2.frequency; for (int x = 0; x < 256; x++) SP(x, 186 + (int)(cosf(x * 0.05f - tick * f * 0.0008f) * 18.0f), 7); }
    if (triangleChannel.amplitude) { float f = triangleChannel.frequency; for (int x = 0; x < 256; x++) SP(x, 128 + (int)(sinf(x * 0.04f + tick * f * 0.0006f) * 22.0f), 9); }
    if (sawToothChannel.amplitude) { int sy = (int)(tick * sawToothChannel.frequency * 0.002f) & 0xFF; for (int x = 0; x < 256; x++) SP(x, sy, 15); }

    float hit = hitFade();
    if (hit < 0.02f) return;
    int note = hitNote, col = drumColor(note);

    if (note == 35 || note == 36) {
        float r = (1.0f - hit) * 130.0f;
        for (int a = 0; a < 360; a += 2) { float rad = a * PI / 180.0f; SP(128 + (int)(cosf(rad) * r), 210 + (int)(sinf(rad) * r * 0.35f), col); }
        for (int x = 0; x < 256; x++) for (int y = (int)(232 - hit * 28); y < 256; y++) SP(x, y, wc(col + (int)(hit * 3)));
    }
    else if (note >= 37 && note <= 40) {
        int w = (int)(hit * 3.0f);
        for (int i = 0; i < 256; i++) for (int dw = -w; dw <= w; dw++) { SP(i + dw, i, col); SP(255 - i + dw, i, wc(col + 3)); }
    }
    else if (note == 42 || note == 44) {
        static const int corners[4][2] = { {16,16},{240,16},{16,240},{240,240} };
        for (int ci = 0; ci < 4; ci++) for (int k = 0; k < 20; k++) {
            float ang = k * 0.314f + tick * 0.5f, rad = hit * 28.0f;
            SP(corners[ci][0] + (int)(cosf(ang) * rad), corners[ci][1] + (int)(sinf(ang) * rad), col);
        }
    }
    else if (note == 46) {
        for (int x = 0; x < 256; x++) {
            float ang = x * PI / 256.0f, rad = (1.0f - hit) * 80.0f;
            SP(128 + (int)(cosf(ang) * rad), (int)(sinf(ang) * rad * 0.6f), col);
            SP(128 - (int)(cosf(ang) * rad), (int)(sinf(ang) * rad * 0.6f), wc(col + 1));
        }
    }
    else if (note == 49 || note == 52 || note == 55 || note == 57) {
        float r = (1.0f - hit) * 150.0f;
        for (int a = 0; a < 360; a += 2) { float rad = a * PI / 180.0f; for (int dr = 0; dr < 5; dr++) SP(128 + (int)(cosf(rad) * (r + dr * 7)), 128 + (int)(sinf(rad) * (r + dr * 7)), wc(col + dr)); }
    }
    else if (note == 41 || note == 43 || note == 45 || note == 47 || note == 48 || note == 50) {
        int ox = (note % 2 == 1) ? 64 : 192;
        float r = (1.0f - hit) * 70.0f + 15.0f;
        for (int a = 0; a < 360; a += 3) { float rad = a * PI / 180.0f; SP(ox + (int)(cosf(rad) * r), 128 + (int)(sinf(rad) * r), col); }
    }
    else {
        float r = (1.0f - hit) * 110.0f;
        for (int a = 0; a < 360; a += 3) { float rad = a * PI / 180.0f; SP(128 + (int)(cosf(rad) * r), 128 + (int)(sinf(rad) * r), col); }
    }
}

// ════════════════════════════════════════════════════════════════════════════
// VIZ 6 – WARP WEB
//   16x16 grid of H/V lines bent by sine waves whose amplitude is driven
//   by channel frequencies.  Drum hits send a double-ring ripple through.
// ════════════════════════════════════════════════════════════════════════════
void VizWarpWeb() {
    float sq1w = squareChannel1.amplitude ? squareChannel1.frequency / 180.0f : 2.5f;
    float sq2w = squareChannel2.amplitude ? squareChannel2.frequency / 220.0f : 2.0f;
    float trw = triangleChannel.amplitude ? triangleChannel.frequency / 260.0f : 1.8f;
    float saww = sawToothChannel.amplitude ? sawToothChannel.frequency / 300.0f : 2.2f;

    for (int row = 0; row < 16; row++) {
        int baseY = row * 16 + 8, col = wc(row + (int)(tick * 0.018f));
        for (int x = 0; x < 256; x++) {
            float wy = sinf(x * 0.04f + tick * 0.050f) * sq1w * 8.0f + cosf(x * 0.07f - tick * 0.030f) * trw * 5.0f;
            SP(x, baseY + (int)wy, col);
        }
    }
    for (int c = 0; c < 16; c++) {
        int baseX = c * 16 + 8, col = wc(c + 8 + (int)(tick * 0.018f));
        for (int y = 0; y < 256; y++) {
            float wx = sinf(y * 0.05f + tick * 0.040f) * sq2w * 7.0f + cosf(y * 0.06f - tick * 0.035f) * saww * 5.0f;
            SP(baseX + (int)wx, y, col);
        }
    }
    if (noiseChannel.amplitude && hitFade() > 0.04f) {
        float hit = hitFade(); int col = drumColor(hitNote); float r = (1.0f - hit) * 100.0f;
        for (int a = 0; a < 360; a += 3) {
            float rad = a * PI / 180.0f;
            SP(128 + (int)(cosf(rad) * r), 128 + (int)(sinf(rad) * r), col);
            SP(128 + (int)(cosf(rad) * (r + 6.f)), 128 + (int)(sinf(rad) * (r + 6.f)), wc(col + 2));
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
// VIZ 7 – PLASMA RIBBONS
//   Five wide ribbons whose curvature is driven by channel frequencies.
//   Drum hits send a transverse shockwave through all ribbons simultaneously.
// ════════════════════════════════════════════════════════════════════════════
void VizPlasmaRibbons() {
    float sq1f = squareChannel1.amplitude.load()
        ? squareChannel1.frequency.load()
        : 440.0f;

    float sq2f = squareChannel2.amplitude.load()
        ? squareChannel2.frequency.load()
        : 330.0f;

    float trf = triangleChannel.amplitude.load()
        ? triangleChannel.frequency.load()
        : 220.0f;

    float sawf = sawToothChannel.amplitude.load()
        ? sawToothChannel.frequency.load()
        : 180.0f;

    struct Ribbon { float freqX, freqT, amp, width, yBase; int col; };
    Ribbon ribbons[5] = {
        {sq1f * 0.00020f,0.060f,34.0f,6.0f, 48.0f,13},
        {sq2f * 0.00015f,0.042f,27.0f,5.0f,112.0f, 7},
        {trf * 0.00025f,0.051f,31.0f,7.0f,176.0f, 9},
        {sawf * 0.00020f,0.068f,24.0f,4.0f, 82.0f, 3},
        {0.050f,       0.030f,38.0f,8.0f,144.0f,15},
    };
    float shockAmp = hitFade() * 26.0f;
    int   shockCol = drumColor(hitNote);
    for (auto& rb : ribbons) {
        for (int x = 0; x < 256; x++) {
            float shock = shockAmp * sinf(x * 0.07f + tick * 0.2f);
            float cy = rb.yBase + sinf(x * rb.freqX + tick * rb.freqT) * rb.amp + shock;
            for (int w = -(int)rb.width; w <= (int)rb.width; w++) {
                int y = (int)cy + w; if (y < 0 || y >= 256)continue;
                SP(x, y, (fabsf((float)w) / rb.width < 0.65f) ? rb.col : wc(rb.col + 2));
            }
        }
    }
    if (shockAmp > 4.0f) {
        for (int x = 0; x < 256; x++) {
            int y = (int)(128.0f + sinf(x * 0.1f + tick * 0.25f) * shockAmp);
            SP(x, y, shockCol); SP(x, y + 1, wc(shockCol + 2));
        }
    }
}

// ════════════════════════════════════════════════════════════════════════════
// VIZ 8 – *** ACID TRIP ***
//   Every pixel computed via three rotating coordinate frames fed into a
//   layered sine product.  Channels push each frame's scale into overdrive.
//   Drum hits warp, strobe, and invert in ways unique to each drum family.
// ════════════════════════════════════════════════════════════════════════════
void VizAcidTrip() {
    float hit = hitFade(); int dNote = hitNote, dCol = drumColor(dNote);
    float a1 = tick * 0.021f, a2 = tick * 0.013f, a3 = tick * 0.033f;
    float fm1 = squareChannel1.amplitude ? squareChannel1.frequency / 280.0f : 1.0f;
    float fm2 = squareChannel2.amplitude ? squareChannel2.frequency / 340.0f : 1.0f;
    float fm3 = triangleChannel.amplitude ? triangleChannel.frequency / 380.0f : 1.0f;
    float fm4 = sawToothChannel.amplitude ? sawToothChannel.frequency / 420.0f : 1.0f;
    float warpBias = 0.0f;
    if (dNote == 35 || dNote == 36)   warpBias = hit * 3.2f;
    if (dNote >= 37 && dNote <= 40)   warpBias = hit * 1.6f;
    int  colorShift = (int)(tick * 0.18f) + (int)(hit * 10.0f);
    bool invert = hit > 0.5f && (dNote == 49 || dNote == 52 || dNote == 55 || dNote == 57);

    for (int y = 0; y < 256; y++) for (int x = 0; x < 256; x++) {
        float fx = (x - 128) / 64.0f, fy = (y - 128) / 64.0f;
        float rx1 = fx * cosf(a1) - fy * sinf(a1), ry1 = fx * sinf(a1) + fy * cosf(a1);
        float rx2 = fx * cosf(a2) - fy * sinf(a2), ry2 = fx * sinf(a2) + fy * cosf(a2);
        float rx3 = fx * cosf(a3) - fy * sinf(a3), ry3 = fx * sinf(a3) + fy * cosf(a3);
        float v = sinf(rx1 * 3.0f * fm1 + tick * 0.070f) * cosf(ry1 * 2.8f * fm2 - tick * 0.055f)
            + sinf(rx2 * 4.2f * fm3 + ry2 * 3.1f * fm4 + tick * 0.090f)
            + cosf(sqrtf(rx1 * rx1 + ry2 * ry2) * 5.5f - tick * 0.120f)
            + sinf((rx3 - ry3) * 4.0f + tick * 0.065f + warpBias) * cosf((rx3 + ry3) * 3.5f - tick * 0.048f);
        int c = wc((int)((v + 5.0f) * 2.0f) + colorShift);
        if (invert) c = wc(15 - c);
        SP(x, y, c);
    }
    // Per-family overlays burned on top
    if ((dNote == 35 || dNote == 36) && hit > 0.18f) {
        float r = (1.0f - hit) * 142.0f;
        for (int a = 0; a < 360; a += 2) { float rad = a * PI / 180.0f; for (int dr = 0; dr < 3; dr++) SP(128 + (int)(cosf(rad) * (r + dr)), 128 + (int)(sinf(rad) * (r + dr)), dCol); }
    }
    if ((dNote >= 37 && dNote <= 40) && hit > 0.28f) {
        int w = (int)(hit * 5.0f);
        for (int i = 0; i < 256; i++) for (int dw = -w; dw <= w; dw++) SP(i + dw, i, dCol);
    }
    if ((dNote == 42 || dNote == 44) && hit > 0.1f) {
        int r = (int)(hit * 22.0f);
        for (int k = 0; k < r; k++) { SP(k, k, dCol); SP(255 - k, k, dCol); SP(k, 255 - k, dCol); SP(255 - k, 255 - k, dCol); }
    }
    if ((dNote == 51 || dNote == 53 || dNote == 59) && hit > 0.1f) {
        for (int i = 0; i < 200; i++) { float u = i * 0.08f, r = u * 6.0f; SP(128 + (int)(cosf(u + tick * 0.05f) * r), 128 + (int)(sinf(u + tick * 0.05f) * r), dCol); }
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Dispatch
// ════════════════════════════════════════════════════════════════════════════
void Visualize() {
    tick++;

    // Detect new drum hit; re-trigger on same-note if cooldown is nearly spent
    int curNote = noiseChannel.midiNote.load();
    if (curNote != 0 && (curNote != lastMidiNote || hitCooldown < 10)) {
        hitNote = curNote; hitCooldown = 30; lastMidiNote = curNote;
    }
    if (hitCooldown > 0) hitCooldown--;

    switch (currentViz) {
    case 0: VizAurora();        break;
    case 1: VizRadialPulse();   break;
    case 2: VizLissajous();     break;
    case 3: VizStarTunnel();    break;
    case 4: VizCrystalGrid();   break;
    case 5: VizDrumReactor();   break;
    case 6: VizWarpWeb();       break;
    case 7: VizPlasmaRibbons(); break;
    case 8: VizAcidTrip();      break;
    }
}

// ════════════════════════════════════════════════════════════════════════════
// Game
// ════════════════════════════════════════════════════════════════════════════
static const int BG[NUM_VIZ] = { 5,5,5,5,5,5,5,5,5 };

class TestGame : public Game {
    int x = 0, y = 0;
    AnimatedCompositeSprite jake;
    void Start() override {
        initAudio();
        
        std::string fileName = "GGXDizzy";
        std::cin >> fileName;
        playing = fileName;
        jake.loadFromFile("Abacrazy.cas");
        music.loadFromFile(fileName + ".ns");
        music.play();
    }
    void Update() override {
        bool spaceNow = isKeyPressed(Key::Space);
        if (spaceNow && !spaceWasDown) currentViz = (currentViz + 1) % NUM_VIZ;
        spaceWasDown = spaceNow;
        if (isKeyPressed(Key::Left))  x--;
        if (isKeyPressed(Key::Right)) x++;
        if (isKeyPressed(Key::Up))    y--;
        if (isKeyPressed(Key::Down))  y++;
    }
    void Draw() override {
        ClearFrameBuffer(BG[currentViz]);
        Visualize();
        Print("NOW PLAYING: " + playing, 11, 0, 256 - 12 * 4, 2);
        Print(VIZ_NAMES[currentViz], 13, 0, 4, 2);
    }
};

void main() {
    TestGame testGame;
    testGame.gameName = "Nukoli";
    run(testGame);
}